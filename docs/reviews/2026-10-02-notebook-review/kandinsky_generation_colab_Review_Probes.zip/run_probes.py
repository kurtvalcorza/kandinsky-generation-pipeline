"""Probes for the Notebook Review Framework v1 review of tutorials/kandinsky_generation_colab.ipynb (prefix KGN).

Run from the repository root (a checkout of the reviewed commit):
    KMP_DUPLICATE_LIB_OK=TRUE python run_probes.py [--evidence <dir with the archived Kaggle executor outputs>]

CPU only. No model weights, no GPU, no network. Writes results.json and source_manifest.json next to this file.
The hosted-run probes (P05, P06) read the executor's own evaluation_report.json files for blob 26a6d018
(archived at .agent/backups/kandinsky-kaggle-2026-09-29/out-pilot/ in Kurt's workspace); they are skipped if absent.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import io
import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
NB = Path("tutorials/kandinsky_generation_colab.ipynb")
EXPECTED_BLOB = "26a6d01839ffaded22e2316b05b1573f5cc0b434"
RESULTS: dict = {}


def record(pid: str, ok: bool, **detail) -> None:
    RESULTS[pid] = {"ok": bool(ok), **detail}
    print(pid, "PASS" if ok else "FLAG", json.dumps(detail, default=str)[:400])


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cells():
    nb = json.loads(NB.read_text(encoding="utf-8"))
    return nb, [("".join(c["source"]), c) for c in nb["cells"]]


def md_text(all_cells) -> list[tuple[int, str]]:
    return [(i, s) for i, (s, c) in enumerate(all_cells) if c["cell_type"] == "markdown"]


def p01_parse():
    nb, all_cells = cells()
    code = [(i, s) for i, (s, c) in enumerate(all_cells) if c["cell_type"] == "code"]
    compiled = 0
    for _i, s in code:
        ast.parse(s)
        compiled += 1
    outputs = sum(1 for _s, c in all_cells if c["cell_type"] == "code" and (c.get("outputs") or c.get("execution_count")))
    meta = nb["metadata"].get("dimer", {})
    record("P01_parse_hygiene", compiled == len(code) and outputs == 0, n_cells=len(all_cells), n_code=len(code),
           n_markdown=len(all_cells) - len(code), compiled=compiled, persisted_outputs=outputs,
           profile=meta.get("profile"), mode=meta.get("pedagogical_mode") or meta.get("mode"),
           spec=meta.get("notebook_spec") or meta.get("spec_version"),
           generated_from_revision=meta.get("generated_from", {}).get("revision"))


def p02_blob():
    blob = subprocess.run(["git", "hash-object", str(NB)], capture_output=True, text=True).stdout.strip()
    head = subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip()
    changed = subprocess.run(["git", "diff", "--name-only", "256fcb2", "HEAD"], capture_output=True, text=True).stdout.split()
    record("P02_blob_identity", blob == EXPECTED_BLOB and str(NB).replace("\\", "/") not in changed,
           head=head, notebook_blob=blob, hosted_evidence_blob=EXPECTED_BLOB, files_changed_256fcb2_to_head=changed)


def p03_isolated_install():
    _nb, all_cells = cells()
    code = "\n".join(s for s, c in all_cells if c["cell_type"] == "code" and "CARRIED_FILES" not in s)
    md = "\n".join(s for _i, s in md_text(all_cells))
    kernel_pip = re.findall(r"(?<!uv )pip install|-m pip|sys\.executable", code)
    record("P03_isolated_install", not kernel_pip and "--require-hashes" in code and "--managed-python" in code
           and not re.search(r"restart (the|your) (runtime|session|kernel)", md, re.I),
           kernel_pip_hits=kernel_pip, require_hashes="--require-hashes" in code, managed_python="--managed-python" in code,
           restart_request_in_prose=bool(re.search(r"restart (the|your) (runtime|session|kernel)", md, re.I)))


def p04_carrier_parity():
    _nb, all_cells = cells()
    carrier = next(s for s, _c in all_cells if "CARRIED_FILES = " in s)
    tree = ast.parse(carrier)
    files = None
    for node in tree.body:
        if isinstance(node, ast.Assign) and getattr(node.targets[0], "id", "") == "CARRIED_FILES":
            files = ast.literal_eval(node.value)
    repo_map = {"requirements.txt": "tutorials/requirements-colab.lock.txt"}
    mism, checked = [], 0
    for rel, text in files.items():
        if rel == "source.json":
            continue
        src = Path(repo_map.get(rel, rel))
        if not src.exists():
            alt = [p for p in Path(".").rglob(Path(rel).name) if "outputs" not in p.parts and ".git" not in p.parts]
            src = alt[0] if alt else src
        checked += 1
        if not src.exists() or src.read_text(encoding="utf-8").replace("\r\n", "\n") != text:
            mism.append(rel)
    record("P04_carrier_parity", not mism, carried=len(files), compared=checked, mismatches=mism)


def load_reports(evidence: Path | None):
    if evidence is None:
        return None
    default = list((evidence / "dimer-nb2-kandinsky-generation" / "v3").rglob("kandinsky_generation_evaluation_report.json"))
    byod = list((evidence / "dimer-nb2-kandinsky-generation-byod").rglob("kandinsky_generation_evaluation_report.json"))
    if not default or not byod:
        return None
    return {"default": default[0], "byod": byod[0]}


def p05_timestep_direction(reports):
    _nb, all_cells = cells()
    md = {i: s for i, s in md_text(all_cells)}
    prose_small = "usually highest at the smallest timesteps" in md.get(25, "")
    if reports is None:
        record("P05_timestep_direction", prose_small, skipped_hosted="evidence not found", prose_says_highest_at_small_t=prose_small)
        return
    out = {}
    for name, path in reports.items():
        rep = json.loads(path.read_text(encoding="utf-8"))
        bt = rep["frozen"]["test"]["by_timestep"]
        vals = [bt[k] for k in sorted(bt, key=int)]
        out[name] = {"by_timestep": bt, "monotone_decreasing": all(a > b for a, b in zip(vals, vals[1:])),
                     "share_of_mean_t100": round(vals[0] / len(vals) / rep["frozen"]["test"]["denoising_mse"], 3)}
    ok = prose_small and all(v["monotone_decreasing"] for v in out.values())
    record("P05_timestep_direction", ok, prose_says_highest_at_small_t=prose_small, hosted=out,
           note="sibling KCD-M1 (loss said to rise with t) is NOT repeated here")


def p06_ceiling(reports):
    _nb, all_cells = cells()
    md_all = "\n".join(s for _i, s in md_text(all_cells))
    ceiling_mentions = len(re.findall(r"ceiling", md_all))
    self_inclusion_disclosed = bool(re.search(r"include[s]? (each|the|its own) photo|photo itself|scored against itself", md_all, re.I))
    metrics_src = Path("src/kandinsky_generation_pipeline/metrics.py").read_text(encoding="utf-8")
    docstring_says_other = "references = the other records" in metrics_src
    note_says_itself = "references include each photo itself" in metrics_src
    detail = {"ceiling_mentions_in_markdown": ceiling_mentions, "self_inclusion_disclosed_in_notebook": self_inclusion_disclosed,
              "metrics_docstring_says_other_records": docstring_says_other, "metrics_note_says_includes_itself": note_says_itself}
    if reports is not None:
        for name, path in reports.items():
            rep = json.loads(path.read_text(encoding="utf-8"))
            comp = rep["comparison"]
            real = rep["real_photo_ceiling"]
            # Unit-norm embeddings; with k references per caption including the photo itself, r = cos(a, mean/|mean|).
            # For k = 2: r = sqrt((1 + c) / 2), so the leave-one-out photo-to-photo cosine is c = 2 r^2 - 1.
            per_caption: dict[str, int] = {}
            for e in real["per_image"]:
                per_caption[e["prompt"]] = per_caption.get(e["prompt"], 0) + 1
            loo = None
            if set(per_caption.values()) == {2}:
                cs = [2 * (e["reference_similarity"] / 100) ** 2 - 1 for e in real["per_image"]]
                loo = round(100 * sum(cs) / len(cs), 3)
            detail[name] = {
                "clip_prompt_similarity": comp["clip_prompt_similarity"],
                "label_accuracy": comp["label_accuracy"],
                "reference_similarity": comp["reference_similarity"],
                "prompt_similarity_exceeds_ceiling": comp["clip_prompt_similarity"]["frozen"] > comp["clip_prompt_similarity"]["real_photos"],
                "references_per_caption": sorted(set(per_caption.values())),
                "real_reference_similarity_leave_one_out_estimate": loo,
            }
    record("P06_real_photo_ceiling", False, **detail)


def synth_zip(layout, size=320, dup_variant=False):
    from PIL import Image

    buf = io.BytesIO()
    rows = ["id,file,caption"]
    with zipfile.ZipFile(buf, "w") as z:
        n = 0
        for cap, count in layout:
            for j in range(count):
                img = Image.new("RGB", (size, size), (37 * n % 256, 91 * n % 256, 53 * n % 256))
                b = io.BytesIO()
                img.save(b, "PNG")
                z.writestr(f"img{n}.png", b.getvalue())
                rows.append(f"r{n},img{n}.png,{cap}")
                n += 1
        if dup_variant:
            img = Image.new("RGB", (size, size), (250, 3, 250))
            b = io.BytesIO()
            img.save(b, "PNG")
            z.writestr(f"img{n}.png", b.getvalue())
            rows.append(f"r{n},img{n}.png,{layout[0][0]}")
            img.putpixel((0, 0), (251, 3, 250))
            b = io.BytesIO()
            img.save(b, "PNG")
            z.writestr(f"img{n + 1}.png", b.getvalue())
            rows.append(f"r{n + 1},img{n + 1}.png,{layout[0][0]}")
        z.writestr("captions.csv", "\n".join(rows) + "\n")
    return buf.getvalue()


def p07_split_and_independence(tmp: Path):
    sys.path.insert(0, str(Path("src").resolve()))
    from kandinsky_generation_pipeline.samples import load_byod_dataset, split_dataset

    _nb, all_cells = cells()
    md_all = "\n".join(s for _i, s in md_text(all_cells))
    path = tmp / "strat.zip"
    path.write_bytes(synth_zip([("a bird", 5), ("b bird", 5), ("c bird", 5)], dup_variant=True))
    splits = split_dataset(load_byod_dataset(path))
    caps = {k: sorted({r["caption"] for r in v}) for k, v in splits.items()}
    readme = Path("tutorials/README.md").read_text(encoding="utf-8")
    record("P07_split_independence", False,
           independence_stated_in_notebook=bool(re.search(r"independen", md_all, re.I)),
           hold_out_by_caption_phrase=("Hold out by caption, not by image" in md_all),
           captions_per_split=caps, n_per_split={k: len(v) for k, v in splits.items()},
           one_pixel_variant_both_kept=sum(len(v) for v in splits.values()) == 17,
           readme_claims_notebook_says_group_by_observer="photographs of the same individual or observer should be grouped in real data" in readme,
           notebook_says_group_in_real_data=bool(re.search(r"(same individual|same observer).{0,80}group|group.{0,80}(individual|observer)", md_all, re.I)))


def p08_overlap():
    _nb, all_cells = cells()
    md_all = "\n".join(s for _i, s in md_text(all_cells))
    hit = re.search(r"(overlap|pretraining data|training data may|memoris|memoriz)", md_all, re.I)
    record("P08_pretraining_overlap_statement", bool(hit), statement_found=bool(hit))


def p09_duration():
    _nb, all_cells = cells()
    c0 = all_cells[0][0]
    rv = Path("docs/release-verification.md").read_text(encoding="utf-8")
    readme = Path("tutorials/README.md").read_text(encoding="utf-8")
    nb_unrecorded = "duration has not yet been recorded" in c0
    readme_unrecorded = "not yet recorded for this revision" in readme
    rv_measured = "795.8 s" in rv
    rv_contradiction = "No run of the isolated-environment notebook (generator `build_notebook.py/3.0`) is recorded yet" in rv
    record("P09_duration_and_record_consistency", not (nb_unrecorded or readme_unrecorded or rv_contradiction),
           notebook_says_unrecorded=nb_unrecorded, tutorials_readme_says_unrecorded=readme_unrecorded,
           release_record_has_795_8_s=rv_measured, release_record_manual_section_says_none_recorded=rv_contradiction)


def p10_byod_minimum(tmp: Path):
    sys.path.insert(0, str(Path("src").resolve()))
    from kandinsky_generation_pipeline.samples import load_byod_dataset, split_dataset

    layouts = {
        "4 images, 1 caption": [("a bird", 4)],
        "5 images, 1 caption": [("a bird", 5)],
        "4 images: 3 + 1": [("a bird", 3), ("b bird", 1)],
        "6 images, 2 captions x 3": [("a bird", 3), ("b bird", 3)],
        "6 images, 1 caption": [("a bird", 6)],
        "8 images, 2 captions x 4": [("a bird", 4), ("b bird", 4)],
    }
    out = {}
    for name, layout in layouts.items():
        p = tmp / (re.sub(r"\W+", "_", name) + ".zip")
        p.write_bytes(synth_zip(layout))
        try:
            s = split_dataset(load_byod_dataset(p))
            out[name] = "accepted " + " / ".join(str(len(s[k])) for k in ("train", "validation", "test"))
        except ValueError as exc:
            out[name] = f"refused: {exc}"
    meets_stated = ["4 images, 1 caption", "5 images, 1 caption", "4 images: 3 + 1", "6 images, 2 captions x 3",
                    "6 images, 1 caption", "8 images, 2 captions x 4"]
    refused = [n for n in meets_stated if out[n].startswith("refused")]
    record("P10_byod_stated_minimum", not refused, results=out, stated_contract="at least four images, and at least one caption with three or more images (cell 0)",
           refused_although_meeting_stated_contract=refused)


def p11_activity_isolation():
    src = Path("tools/tutorial_stages.py").read_text(encoding="utf-8")
    body = src[src.index("def stage_evaluate"):src.index("def stage_reload")]
    act = src[src.index("def stage_activity"):]
    act = act[:act.index("\ndef ", 10)] if "\ndef " in act[10:] else act
    record("P11_activity_rerun_isolation", "activity" not in body and 'write_output("activity.json"' in act and "write_state" not in act,
           evaluate_reads_activity="activity" in body, activity_writes_only_activity_json='write_output("activity.json"' in act and "write_state" not in act)


def p12_static_gates():
    res = {}
    for name, cmd in {
        "pytest_offline": [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests/test_pipeline.py", "tests/test_samples.py",
                           "tests/test_adaptation.py", "tests/test_role_helpers.py", "tests/test_import_boundary.py",
                           "tests/test_notebook_parity.py", "tests/test_tutorial_stages.py"],
        "validate_release_assets": [sys.executable, "tools/validate_release_assets.py"],
        "build_check": [sys.executable, "tools/build_notebook.py", "--check"],
    }.items():
        try:
            # The package is not installed in the probe interpreter; tests that spawn a subprocess need src on PYTHONPATH.
            env = dict(__import__("os").environ, PYTHONPATH=str(Path("src").resolve()))
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=600, encoding="utf-8", errors="replace", env=env)
            tail = (r.stdout + r.stderr).strip().splitlines()[-3:]
            res[name] = {"exit": r.returncode, "tail": tail}
        except subprocess.TimeoutExpired:
            res[name] = {"exit": None, "tail": ["timeout"]}
    record("P12_static_gates", all(v["exit"] == 0 for v in res.values()), **res)


def manifest(reports):
    files = [NB, Path("tools/notebook_template.py"), Path("tools/build_notebook.py"), Path("tools/tutorial_stages.py"),
             Path("tools/validate_release_assets.py"), Path("src/kandinsky_generation_pipeline/metrics.py"),
             Path("src/kandinsky_generation_pipeline/samples.py"), Path("src/kandinsky_generation_pipeline/pipeline.py"),
             Path("docs/release-verification.md"), Path("tutorials/README.md"), Path("README.md"), Path("STATUS.md"),
             Path("MODEL_CARD.md"), Path("weights/kandinsky-2-2-decoder/scheduler/scheduler_config.json")]
    m = {str(p).replace("\\", "/"): sha256(p) for p in files if p.exists()}
    if reports:
        for name, path in reports.items():
            m[f"hosted_evidence/{name}/kandinsky_generation_evaluation_report.json"] = sha256(path)
    (HERE / "source_manifest.json").write_text(json.dumps(m, indent=1) + "\n", encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--evidence", type=Path, default=None)
    args = ap.parse_args()
    tmp = HERE / "_tmp"
    tmp.mkdir(exist_ok=True)
    reports = load_reports(args.evidence)
    for fn in (p01_parse, p02_blob, p03_isolated_install, p04_carrier_parity):
        fn()
    p05_timestep_direction(reports)
    p06_ceiling(reports)
    p07_split_and_independence(tmp)
    p08_overlap()
    p09_duration()
    p10_byod_minimum(tmp)
    p11_activity_isolation()
    p12_static_gates()
    manifest(reports)
    RESULTS["_environment"] = {"python": sys.version.split()[0], "platform": sys.platform, "cpu_only": True}
    (HERE / "results.json").write_text(json.dumps(RESULTS, indent=1, default=str) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
